﻿module Soevnn.Data
open Soevnn.Core
open Soevnn.Serialization
open System.IO

type tryload<'r> =
| Result of 'r
| Eos
| TypeMismatch

type SerializationTemplate =
| StInt
| StFloat
| StBool
| StString
| StNeuralAddress
| StTuple of SerializationTemplate list
| StList of SerializationTemplate
| StStruct of (string * SerializationTemplate) list

            
   

let LiftOptionTuple2 (a: 'a option, b: 'b option) =
    if a.IsSome && b.IsSome then
        Some (a.Value,b.Value)
    else
        None
let LiftOptionTuple3 (a: 'a option, b: 'b option, c : 'c option) =
    if a.IsSome && b.IsSome && c.IsSome then
        Some (a.Value,b.Value,c.Value)
    else
        None
let LiftOptionTuple4 (a: 'a option, b: 'b option, c : 'c option, d : 'd option) =
    if a.IsSome && b.IsSome && c.IsSome && d.IsSome then
        Some (a.Value,b.Value,c.Value,d.Value)
    else
        None

let SaveBasic (ns : NervousSystem) (neurons : (NeuralAddress * Neuron) []) (saveto : System.IO.BinaryWriter) =
    let saveint (v:int) = saveto.Write(int TypeCode.Int); saveto.Write(v)
    let savestring (v:string) = saveto.Write(int TypeCode.String); saveto.Write(v)
    let savefloat (v:float) = saveto.Write(int TypeCode.Float); saveto.Write(v)
    let savebool (v:bool) = saveto.Write(int TypeCode.Bool); saveto.Write(v)
    let saveneuraladdress (v:NeuralAddress) = 
        saveto.Write(int TypeCode.NeuralAddress)
        saveto.Write(v.StructureIndex)
        saveto.Write(v.GroupIndex)
        saveto.Write(v.ClusterIndex)
        saveto.Write(v.NeuronIndex)
    let savelist (l:int) = saveto.Write(int TypeCode.List); saveto.Write(l)
   
    savestring("Soevnn")
    saveint(0) // Major Version
    saveint(1) // Minor Version
    saveint(1) // Revision Version

let LoadBasic (loadfrom : System.IO.BinaryReader) =
   
    let loadstring () = if loadfrom.ReadInt32() <> int TypeCode.String then None else Some <| loadfrom.ReadString()
    let loadint () = if loadfrom.ReadInt32() <> int TypeCode.Int then None else Some <| loadfrom.ReadInt32()
    let loadfloat () = if loadfrom.ReadInt32() <> int TypeCode.Float then None else Some <| loadfrom.ReadDouble()
    let loadbool () = if loadfrom.ReadInt32() <> int TypeCode.Bool then None else Some <| loadfrom.ReadBoolean()
    let loadneuraladdress () = if loadfrom.ReadInt32() <> int TypeCode.NeuralAddress then None else Some <| NeuralAddress(loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32())
   
    let loadlist (iter : int -> 'i option) = 
        if loadfrom.ReadInt32() <> int TypeCode.List then 
            None 
        else 
            let l = [for i in [ 0 .. loadfrom.ReadInt32()- 1] do yield iter i] 
            if List.forall Option.isSome l then
                List.collect (function | Some v -> [v] | None -> []) l
                |> Some
            else
                None

    if loadstring() <> Some "Soevnn" then
        None
    else
        let majorversion = loadint()
        let minorversion = loadint()
        let revision = loadint()
        let version = (majorversion,minorversion,revision)
        match version with
        | (Some 0,Some 1,Some 1) ->
            Some()
        | _ -> None

let SaveMusclesAndSenses (ns : NervousSystem) (neurons : (NeuralAddress * Neuron) []) (saveto : System.IO.BinaryWriter) =
    let saveint (v:int) = saveto.Write(int TypeCode.Int); saveto.Write(v)
    let savestring (v:string) = saveto.Write(int TypeCode.String); saveto.Write(v)
    let savefloat (v:float) = saveto.Write(int TypeCode.Float); saveto.Write(v)
    let savebool (v:bool) = saveto.Write(int TypeCode.Bool); saveto.Write(v)
    let saveneuraladdress (v:NeuralAddress) = 
        saveto.Write(int TypeCode.NeuralAddress)
        saveto.Write(v.StructureIndex)
        saveto.Write(v.GroupIndex)
        saveto.Write(v.ClusterIndex)
        saveto.Write(v.NeuronIndex)
    let savelist (l:int) = saveto.Write(int TypeCode.List); saveto.Write(l)
    
    savestring("Soevnn")
    saveint(0) // Major Version
    saveint(1) // Minor Version
    saveint(1) // Revision Version
    
    savelist ns.Muscles.Length
    List.iter saveneuraladdress ns.Muscles
    savelist ns.Senses.Length
    List.iter saveneuraladdress ns.Senses

let LoadMuscleAndSenses (loadfrom : System.IO.BinaryReader) =
   
    let loadstring () = if loadfrom.ReadInt32() <> int TypeCode.String then None else Some <| loadfrom.ReadString()
    let loadint () = if loadfrom.ReadInt32() <> int TypeCode.Int then None else Some <| loadfrom.ReadInt32()
    let loadfloat () = if loadfrom.ReadInt32() <> int TypeCode.Float then None else Some <| loadfrom.ReadDouble()
    let loadbool () = if loadfrom.ReadInt32() <> int TypeCode.Bool then None else Some <| loadfrom.ReadBoolean()
    let loadneuraladdress () = if loadfrom.ReadInt32() <> int TypeCode.NeuralAddress then None else Some <| NeuralAddress(loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32())
   
    let loadlist (iter : int -> 'i option) = 
        if loadfrom.ReadInt32() <> int TypeCode.List then 
            None 
        else 
            let l = [for i in [ 0 .. loadfrom.ReadInt32()- 1] do yield iter i] 
            if List.forall Option.isSome l then
                List.collect (function | Some v -> [v] | None -> []) l
                |> Some
            else
                None

    if loadstring() <> Some "Soevnn" then
        None
    else
        let version = (loadint(),loadint(),loadint())
        match version with
        | (Some 0,Some 1,Some 1) ->
            let muscles = loadlist (ignore >> loadneuraladdress)
            let senses = loadlist (ignore >> loadneuraladdress)
            Some(muscles,senses)
        | _ -> None


let SaveNeuralTypes (ns : NervousSystem) (neurons : (NeuralAddress * Neuron) []) (saveto : System.IO.BinaryWriter) =
    let saveint (v:int) = saveto.Write(int TypeCode.Int); saveto.Write(v)
    let savestring (v:string) = saveto.Write(int TypeCode.String); saveto.Write(v)
    let savefloat (v:float) = saveto.Write(int TypeCode.Float); saveto.Write(v)
    let savebool (v:bool) = saveto.Write(int TypeCode.Bool); saveto.Write(v)
    let saveneuraladdress (v:NeuralAddress) = 
        saveto.Write(int TypeCode.NeuralAddress)
        saveto.Write(v.StructureIndex)
        saveto.Write(v.GroupIndex)
        saveto.Write(v.ClusterIndex)
        saveto.Write(v.NeuronIndex)
    let savelist (l:int) = saveto.Write(int TypeCode.List); saveto.Write(l)
    
    savestring("Soevnn")
    saveint(0) // Major Version
    saveint(1) // Minor Version
    saveint(1) // Revision Version
    
    savelist ns.Muscles.Length
    List.iter saveneuraladdress ns.Muscles
    savelist ns.Senses.Length
    List.iter saveneuraladdress ns.Senses

    
    let rec getneuraltypes (si:int) (gi:int) (ntl : NeuralType list) = 
        if si >= ns.Structures.Length then
            ntl
        else if gi >= ns.Structures.[si].Groups.Length then
            getneuraltypes (si+1) 0 ntl
        else
            if List.contains (ns.Structures.[si].Groups.[gi].NeuralType) ntl then
                getneuraltypes si (gi+1) ntl
            else
                getneuraltypes si (gi+1) (ns.Structures.[si].Groups.[gi].NeuralType :: ntl)
            
    let ntl = getneuraltypes 0 0 []
    let ntlmap = 
        ntl
        |> List.mapi (fun i (nt:NeuralType) -> (nt,i))
        |> Map.ofList

    ntl.Length |> savelist
    for nt in ntl do
        match nt.NeuralType with
        | NtOffset ->       saveint 0
        | NtScaling ->      saveint 1
        | NtSpiking ->      saveint 2
        nt.DirectInverseBalance |> savefloat
        nt.AdaptionRate |> savefloat
        nt.CurrentAccumRate |> savefloat
        nt.ExpectedAccumRate |> savefloat
        nt.AxonalSynapses |> saveint
        nt.DendritricSynapsesMin |> saveint
        nt.DendritricSynapsesMax |> saveint
        nt.IntraInterBalanceCluster |> savefloat
        nt.IntraInterBalanceGroup |> savefloat
        nt.IntraInterBalanceStructure |> savefloat
        nt.ClusterSize |> saveint
        match nt.Pathway with
        | NpCluster ->      saveint 0
        | NpGroup ->        saveint 1
        | NpStructure ->    saveint 2
        | NpType ->         saveint 3
        nt.SensoryAdaptionRate |> savefloat
        nt.SensoryAdaptions.Length |> savelist
        for sa in nt.SensoryAdaptions do
            sa.Sense |> saveneuraladdress
            sa.Weight |> savefloat
            sa.WidthHeightRatio |> savefloat

let LoadNeuralTypes (loadfrom : System.IO.BinaryReader) =
   
    let loadstring () = if loadfrom.ReadInt32() <> int TypeCode.String then failwith ("Expected a TypeCode of String, but something else."); None else Some <| loadfrom.ReadString()
    let loadint () = if loadfrom.ReadInt32() <> int TypeCode.Int then failwith ("Expected a TypeCode of Int, but something else."); None else Some <| loadfrom.ReadInt32()
    let loadfloat () = if loadfrom.ReadInt32() <> int TypeCode.Float then failwith ("Expected a TypeCode of Float, but something else."); None else Some <| loadfrom.ReadDouble()
    let loadbool () = if loadfrom.ReadInt32() <> int TypeCode.Bool then failwith ("Expected a TypeCode of Bool, but something else."); None else Some <| loadfrom.ReadBoolean()
    let loadneuraladdress () = if loadfrom.ReadInt32() <> int TypeCode.NeuralAddress then failwith ("Expected a TypeCode of NeuralAddress, but something else."); None else Some <| NeuralAddress(loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32())
   
    let loadlist (iter : int -> 'i option) = 
        if loadfrom.ReadInt32() <> int TypeCode.List then 
            failwith ("Expected a TypeCode of List, but something else."); None 
        else 
            let l = [for i = 0 to loadfrom.ReadInt32() - 1 do yield iter i] 
            if List.forall Option.isSome l then
                List.collect (function | Some v -> [v] | None -> []) l
                |> Some
            else
                None

    
    if loadstring() <> Some "Soevnn" then
        None
    else
        let version = (loadint(),loadint(),loadint())
        match version with
        | (Some 0,Some 1,Some 1) ->
            let muscles = loadlist (fun i -> loadneuraladdress())
            let senses = loadlist (fun i -> loadneuraladdress())
            let ntl : NeuralType list option =
                 loadlist 
                    (fun i -> 
                            let neuraltype = 
                                (match loadint() with
                                | Some 0 -> Some NtOffset
                                | Some 1 -> Some NtScaling
                                | Some 2 -> Some NtSpiking
                                | _ -> None)
                            let balanceinverse = loadfloat()
                            let adaptionrate = loadfloat()
                            let currentaccumrate = loadfloat()
                            let expectedaccumfloat = loadfloat()
                            let axonalsynapses = loadint()
                            let synapsemin = loadint()
                            let synapsemax = loadint()
                            let balancecluster = loadfloat()
                            let balancegroup = loadfloat()
                            let balancestructure = loadfloat()
                            let clustersize = loadint()
                            let pathway = 
                                (match loadint() with
                                | Some 0 -> Some NpCluster
                                | Some 1 -> Some NpGroup
                                | Some 2 -> Some NpStructure
                                | Some 3 -> Some NpType
                                | _ -> None)
                            let sensoryadaptionrate = loadfloat()
                            let sensoryadaptions = 
                                loadlist 
                                    (fun al -> 
                                            let sense = loadneuraladdress()
                                            let weight = loadfloat()
                                            let widthheightratio = loadfloat()
                                            match (sense,weight,widthheightratio) with
                                            | (Some s, Some w, Some whr) -> Some {Sense=s;Weight =w;WidthHeightRatio=whr}
                                            | _ -> None
                                            
                                    )
                            if 
                                balancegroup.IsSome &&
                                balancestructure.IsSome &&
                                balancecluster.IsSome &&
                                balanceinverse.IsSome &&
                                synapsemin.IsSome &&
                                synapsemax.IsSome &&
                                axonalsynapses.IsSome &&
                                adaptionrate.IsSome &&
                                currentaccumrate.IsSome &&
                                expectedaccumfloat.IsSome &&
                                clustersize.IsSome &&
                                neuraltype.IsSome &&
                                pathway.IsSome &&
                                sensoryadaptionrate.IsSome &&
                                sensoryadaptionrate.IsSome then

                                    (Some(NeuralType(
                                            balancegroup.Value,
                                            balancestructure.Value,
                                            balancecluster.Value,
                                            balanceinverse.Value,
                                            synapsemin.Value,
                                            synapsemax.Value,
                                            axonalsynapses.Value,
                                            adaptionrate.Value,
                                            currentaccumrate.Value,
                                            expectedaccumfloat.Value,
                                            clustersize.Value,
                                            neuraltype.Value,
                                            pathway.Value,
                                            sensoryadaptionrate.Value,
                                            sensoryadaptions.Value
                                )))
                            else
                                None
                    )

            let ntlmap =
                if ntl.IsSome then
                    ntl.Value
                    |> List.mapi (fun i nt -> (i,nt))
                    |> Map.ofList
                    |> Some
                else
                    None
            LiftOptionTuple2(ntl,ntlmap)
        | _ -> None


let SaveNervousSystem (ns : NervousSystem) (neurons : (NeuralAddress * Neuron) []) (saveto : System.IO.BinaryWriter) =
    let saveint (v:int) = saveto.Write(int TypeCode.Int); saveto.Write(v)
    let savestring (v:string) = saveto.Write(int TypeCode.String); saveto.Write(v)
    let savefloat (v:float) = saveto.Write(int TypeCode.Float); saveto.Write(v)
    let savebool (v:bool) = saveto.Write(int TypeCode.Bool); saveto.Write(v)
    let saveneuraladdress (v:NeuralAddress) = 
        saveto.Write(int TypeCode.NeuralAddress)
        saveto.Write(v.StructureIndex)
        saveto.Write(v.GroupIndex)
        saveto.Write(v.ClusterIndex)
        saveto.Write(v.NeuronIndex)
    let savelist (l:int) = saveto.Write(int TypeCode.List); saveto.Write(l)

    savestring("Soevnn")
    saveint(0) // Major Version
    saveint(1) // Minor Version
    saveint(1) // Revision Version

    savelist ns.Muscles.Length
    List.iter saveneuraladdress ns.Muscles
    savelist ns.Senses.Length
    List.iter saveneuraladdress ns.Senses

    
    let rec getneuraltypes (si:int) (gi:int) (ntl : NeuralType list) = 
        if si >= ns.Structures.Length then
            ntl
        else if gi >= ns.Structures.[si].Groups.Length then
            getneuraltypes (si+1) 0 ntl
        else
            if List.contains (ns.Structures.[si].Groups.[gi].NeuralType) ntl then
                getneuraltypes si (gi+1) ntl
            else
                getneuraltypes si (gi+1) (ns.Structures.[si].Groups.[gi].NeuralType :: ntl)
            
    let ntl = getneuraltypes 0 0 []
    let ntlmap = 
        ntl
        |> List.mapi (fun i (nt:NeuralType) -> (nt,i))
        |> Map.ofList

    ntl.Length |> savelist
    for nt in ntl do
        match nt.NeuralType with
        | NtOffset ->       saveint 0
        | NtScaling ->      saveint 1
        | NtSpiking ->      saveint 2
        nt.DirectInverseBalance |> savefloat
        nt.AdaptionRate |> savefloat
        nt.CurrentAccumRate |> savefloat
        nt.ExpectedAccumRate |> savefloat
        nt.AxonalSynapses |> saveint
        nt.DendritricSynapsesMin |> saveint
        nt.DendritricSynapsesMax |> saveint
        nt.IntraInterBalanceCluster |> savefloat
        nt.IntraInterBalanceGroup |> savefloat
        nt.IntraInterBalanceStructure |> savefloat
        nt.ClusterSize |> saveint
        match nt.Pathway with
        | NpCluster ->      saveint 0
        | NpGroup ->        saveint 1
        | NpStructure ->    saveint 2
        | NpType ->         saveint 3
        nt.SensoryAdaptionRate |> savefloat
        nt.SensoryAdaptions.Length |> savelist
        for sa in nt.SensoryAdaptions do
            sa.Sense |> saveneuraladdress
            sa.Weight |> savefloat
            sa.WidthHeightRatio |> savefloat

    savelist ns.Structures.Length
    for s in ns.Structures do
        savelist s.Groups.Length
        for g in s.Groups do
            saveint (ntlmap.[g.NeuralType])
            g.Clusters.Length |> savelist
            for c in g.Clusters do
                c.Neurons.Length |> savelist
                for na in c.Neurons do
                    na |> saveneuraladdress

    savelist neurons.Length
    for (na,n) in neurons do
        na |> saveneuraladdress
        match n.State with
        | NsOffset(v) ->
            saveint 0
            v.CurrentAccumRate |> savefloat
            v.ExpectedAccumRate |> savefloat
            v.CurrentAccum |> savefloat
            v.ExpectedAccum |> savefloat
        | NsScaling(v) ->
            saveint 1
            v.CurrentAccumRate |> savefloat
            v.ExpectedAccumRate |> savefloat
            v.CurrentAccum |> savefloat
            v.ExpectedAccum |> savefloat
        | NsSpiking(v) ->
            saveint 2
            v.CurrentAccumRate |> savefloat
            v.ExpectedAccumRate |> savefloat
            v.CurrentAccum |> savefloat
            v.ExpectedAccum |> savefloat
        ntlmap.[n.NeuralType] |> saveint
        n.Axon |> savefloat
        n.Dendrites.Length |> savelist
        for (d,i) in n.Dendrites do
            d |> saveneuraladdress
            i |> savebool
        n.MessageQueue.Count |> savelist
        for nms in n.MessageQueue do
            match nms with
            | ConnectInput(ci) -> 
                saveint 0
                ci |> saveneuraladdress
            | DisconnectInput(ci) -> 
                saveint 1
                ci |> saveneuraladdress
            | Die -> 
                saveint 2




let LoadNervousSystem (loadfrom : System.IO.BinaryReader) =
    
    //let loadstring () = if loadfrom.ReadInt32() <> TypeCode.String then None else Some <| loadfrom.ReadString()
    //let loadint () = if loadfrom.ReadInt32() <> TypeCode.Int then None else Some <| loadfrom.ReadInt32()
    //let loadfloat () = if loadfrom.ReadInt32() <> TypeCode.Float then None else Some <| loadfrom.ReadDouble()
    //let loadbool () = if loadfrom.ReadInt32() <> TypeCode.Bool then None else Some <| loadfrom.ReadBoolean()
    //let loadneuraladdress () = if loadfrom.ReadInt32() <> TypeCode.NeuralAddress then None else Some <| NeuralAddress(loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32())
    
    let loadstring () = if loadfrom.ReadInt32() <> int TypeCode.String then failwith ("Expected a TypeCode of String, but got something else."); None else Some <| loadfrom.ReadString()
    let loadint () = if loadfrom.ReadInt32() <> int TypeCode.Int then failwith ("Expected a TypeCode of Int, but got something else."); None else Some <| loadfrom.ReadInt32()
    let loadfloat () = if loadfrom.ReadInt32() <> int TypeCode.Float then failwith ("Expected a TypeCode of Float, but got something else."); None else Some <| loadfrom.ReadDouble()
    let loadbool () = if loadfrom.ReadInt32() <> int TypeCode.Bool then failwith ("Expected a TypeCode of Bool, but got something else."); None else Some <| loadfrom.ReadBoolean()
    let loadneuraladdress () = if loadfrom.ReadInt32() <> int TypeCode.NeuralAddress then failwith ("Expected a TypeCode of NeuralAddress, but got something else."); None else Some <| NeuralAddress(loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32(),loadfrom.ReadInt32())
   
    let loadlist (iter : int -> 'i option) = 
        if loadfrom.ReadInt32() <> int TypeCode.List then 
            failwith ("Expected a TypeCode of List, but got something else.")
            None 
        else 
            let l = [for i = 0 to loadfrom.ReadInt32() - 1 do yield iter i] 
            if List.forall Option.isSome l then
                List.map (Option.get) l
                |> Some
            else
                None

    

    if loadstring() <> Some "Soevnn" then
        None
    else
        let version = (loadint(),loadint(),loadint())
        match version with
        | (Some 0,Some 1,Some 1) ->
            let muscles = loadlist (ignore >> loadneuraladdress)
            let senses = loadlist (ignore >> loadneuraladdress)
            let ntl : NeuralType list option =
                 loadlist 
                    (fun i -> 
                            
                            let neuraltype = 
                                (match loadint() with
                                | Some 0 -> Some NtOffset
                                | Some 1 -> Some NtScaling
                                | Some 2 -> Some NtSpiking
                                | _ -> None)
                            let balanceinverse = loadfloat()
                            let adaptionrate = loadfloat()
                            let currentaccumrate = loadfloat()
                            let expectedaccumfloat = loadfloat()
                            let axonalsynapses = loadint()
                            let synapsemin = loadint()
                            let synapsemax = loadint()
                            let balancecluster = loadfloat()
                            let balancegroup = loadfloat()
                            let balancestructure = loadfloat()
                            let clustersize = loadint()
                            let pathway = 
                                (match loadint() with
                                | Some 0 -> Some NpCluster
                                | Some 1 -> Some NpGroup
                                | Some 2 -> Some NpStructure
                                | Some 3 -> Some NpType
                                | _ -> None)
                            let sensoryadaptionrate = loadfloat()
                            let sensoryadaptions = 
                                loadlist 
                                    (fun al -> 
                                            let sense = loadneuraladdress()
                                            let weight = loadfloat()
                                            let widthheightratio = loadfloat()
                                            match (sense,weight,widthheightratio) with
                                            | (Some s, Some w, Some whr) -> Some {Sense=s;Weight =w;WidthHeightRatio=whr}
                                            | _ -> None
                                            
                                    )
                            if 
                                balancegroup.IsSome &&
                                balancestructure.IsSome &&
                                balancecluster.IsSome &&
                                balanceinverse.IsSome &&
                                synapsemin.IsSome &&
                                synapsemax.IsSome &&
                                axonalsynapses.IsSome &&
                                adaptionrate.IsSome &&
                                currentaccumrate.IsSome &&
                                expectedaccumfloat.IsSome &&
                                clustersize.IsSome &&
                                neuraltype.IsSome &&
                                pathway.IsSome &&
                                sensoryadaptionrate.IsSome &&
                                sensoryadaptionrate.IsSome then

                                    (Some(NeuralType(
                                            balancegroup.Value,
                                            balancestructure.Value,
                                            balancecluster.Value,
                                            balanceinverse.Value,
                                            synapsemin.Value,
                                            synapsemax.Value,
                                            axonalsynapses.Value,
                                            adaptionrate.Value,
                                            currentaccumrate.Value,
                                            expectedaccumfloat.Value,
                                            clustersize.Value,
                                            neuraltype.Value,
                                            pathway.Value,
                                            sensoryadaptionrate.Value,
                                            sensoryadaptions.Value
                                )))
                            else
                                None
                    )

            let ntlmap =
                Option.map
                    (List.mapi (fun i nt -> (i,nt)) >> Map.ofList)
                    ntl
            let ns =
                if ntlmap.IsSome && senses.IsSome && muscles.IsSome then
                    let structures =
                        loadlist (fun s->
                                    let groups =
                                        loadlist (fun g->
                                            let nt = 
                                                match loadint() with
                                                | Some v ->
                                                    ntlmap.Value.[v] |> Some
                                                | None -> None
                                            let clusters =
                                                loadlist (fun c ->
                                                    let addresses =
                                                        loadlist (fun n -> loadneuraladdress())
                                                    match addresses with
                                                    | Some nal -> NeuralCluster(nal) |> Some
                                                    | None -> None
                                                    )
                                            match (clusters,nt) with
                                            | (Some cl, Some ntv) -> NeuralGroup(cl,ntv) |> Some
                                            | _ -> None
                                            )
                                    match groups with
                                    | Some gl -> NeuralStructure(gl) |> Some
                                    | None -> None
                                    )
                    if structures.IsSome then
                        NervousSystem(
                            structures.Value,
                            senses.Value,
                            muscles.Value
                        )
                        |> Some
                    else
                        None
                else
                    None
            let neurons =
                if ntlmap.IsSome && ns.IsSome then
                    loadlist
                        (fun n -> 
                            (
                                loadneuraladdress(),
                                let neuron =
                                    let ns =
                                        (match loadint() with
                                        | Some 0 -> 
                                            match LiftOptionTuple4(loadfloat(),loadfloat(),loadfloat(),loadfloat()) with
                                            | Some (a,b,c,d) -> Some(NsOffset(NeuralTypeOffset(a,b,c,d)))
                                            | _ -> None
                                        | Some 1 -> 
                                            match LiftOptionTuple4(loadfloat(),loadfloat(),loadfloat(),loadfloat()) with
                                            | Some (a,b,c,d) -> Some(NsScaling(NeuralTypeScaling(a,b,c,d)))
                                            | _ -> None
                                        | Some 2 -> 
                                            match LiftOptionTuple4(loadfloat(),loadfloat(),loadfloat(),loadfloat()) with
                                            | Some (a,b,c,d) -> Some(NsSpiking(NeuralTypeSpiking(a,b,c,d)))
                                            | _ -> None
                                        | Some nstc -> failwith ("Expected an int of 0,1,or 2. But instead got: " + string nstc); None
                                        | _ -> failwith "Expected "; None
                                        )
                                    let nt =
                                        let nti = loadint()
                                        match nti with
                                        | Some v -> ntlmap.Value.[v] |> Some
                                        | _ -> None
                                    let axon = loadfloat()
                                    let dl =
                                        loadlist (fun i -> LiftOptionTuple2(loadneuraladdress(),loadbool()))
                                    if ns.IsSome && nt.IsSome && dl.IsSome && axon.IsSome then
                                        Neuron(
                                            ns.Value,
                                            nt.Value,
                                            dl.Value,
                                            axon.Value
                                        ) |> Some
                                    else
                                        None
                                if neuron.IsSome then
                                    if (loadlist (fun i ->
                                            match loadint() with
                                            | Some 0 -> match loadneuraladdress() with | None -> None | Some na -> Some <| neuron.Value.MessageQueue.Enqueue(ConnectInput(na))
                                            | Some 1 -> match loadneuraladdress() with | None -> None | Some na -> Some <| neuron.Value.MessageQueue.Enqueue(DisconnectInput(na))
                                            | Some 2 -> Some <| neuron.Value.MessageQueue.Enqueue(Die)
                                            | _ -> None)).IsSome then
                                        neuron
                                    else
                                        None
                                else
                                    None) |> LiftOptionTuple2
                        
                    )
                else
                    None
            LiftOptionTuple2 (ns,neurons)
        | _ -> None




    







