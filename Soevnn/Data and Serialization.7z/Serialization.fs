﻿module Soevnn.Serialization
open Soevnn.Core
open System
open System.IO
open Microsoft.FSharp.Reflection
open System.Reflection
open System.Linq.Expressions

type TypeIdentifier =
| TiFullName of string
| TiNamespaceName of string * string
| TiName of string

type TypeSearch = { Name : string option; Namespace : string option}

let (|TiSearch|_|) (ti : TypeIdentifier) =
   match ti with
   | TiNamespaceName(nspace,name) -> Some {Name = Some name; Namespace = Some nspace}
   | TiName(name) -> Some {Name = Some name; Namespace = None}
   | _ -> None
type TiCode =
    static member Fullname = 65uy;
    static member NamespaceName = 66uy;
    static member Name = 67uy;

let TypeMatchesTypeIdentifier (typ : Type) (ti : TypeIdentifier) =
    match ti with
    | TiFullName fullname when typ.FullName = fullname -> true
    | TiNamespaceName(nspace,name) when typ.Namespace = nspace && typ.Name = name -> true
    | TiName(name) when typ.Name = name -> true
    | _ -> false



type SerializationTemplate =
| StUnknown
| StInt
| StFloat
| StBool
| StString
| StNeuralAddress
| StTuple of SerializationTemplate array
| StList of SerializationTemplate
| StArray of SerializationTemplate
| StMap of SerializationTemplate * SerializationTemplate
| StStruct of 
    SerializationTemplate array // constructor parameter types
    * SerializationTemplate array // generic parameters
    * TypeIdentifier
| StRecord of SerializationTemplate array * TypeIdentifier // FullName consistency not guarenteed across versions. Name can work, but they have an assembly value of null. May need new mechanism. Maybe use a combination of Name and duck typing. Include attributes in duck typing and then an attribute describing the actual namespace and assembly can optionally be included that way.
| StUnion of 
    SerializationTemplate array array // properties of cases
    * SerializationTemplate array // generic parameters
    * TypeIdentifier

let rec SerializationTemplateToType (st : SerializationTemplate) =
    match st with
    | StInt -> typeof<int>
    | StFloat -> typeof<float>
    | StBool -> typeof<bool>
    | StString -> typeof<string>
    | StNeuralAddress -> typeof<NeuralAddress>
    | StTuple(sta) ->
        FSharpType.MakeTupleType([|for st in sta do yield SerializationTemplateToType st|])
    | StList(st) ->
        typedefof<List<int>>.MakeGenericType([|SerializationTemplateToType st|])
    | StArray(st) ->
        (SerializationTemplateToType st).MakeArrayType()
    | StMap(stkey,stitem) ->
        typedefof<Map<int,int>>.MakeGenericType([|SerializationTemplateToType stkey; SerializationTemplateToType stitem|])
    | StStruct(cpa,gpa,ti) ->
        match ti with
        | TiFullName(fn) -> Type.GetType(fn)
        | TiSearch {Name = n; Namespace = ns} -> 
            let td =
                AppDomain.CurrentDomain.GetAssemblies()
                |> Array.collect (fun (a : Assembly) -> a.GetTypes())
                |> Array.find (fun (typ : Type) -> 
                    typ.IsValueType 
                    && (match ns with | None -> true | Some ns -> typ.Namespace = ns )
                    && (match n with | None -> true | Some n -> typ.Name = n)
                    && gpa.Length = typ.GetGenericArguments().Length
                    && Array.exists 
                        (fun (ci : ConstructorInfo) -> 
                            Array.forall2 
                                (fun (p : SerializationTemplate) (pi : ParameterInfo) -> SerializationTemplateToType p = pi.ParameterType) 
                                cpa 
                                (ci.GetParameters())) 
                        (typ.GetConstructors(BindingFlags.NonPublic ||| BindingFlags.Public ||| BindingFlags.Instance ||| BindingFlags.Static))
                    )
            if gpa.Length > 0 then
                td.MakeGenericType([|for st in gpa do yield SerializationTemplateToType st|])
            else
                td
    | StUnion(cases,gpa,ti) ->
        match ti with
        | TiFullName(fn) -> Type.GetType(fn)
        | TiSearch {Name = n; Namespace = ns} -> 
            let td =
                AppDomain.CurrentDomain.GetAssemblies()
                |> Array.collect (fun (a : Assembly) -> a.GetTypes())
                |> Array.find (fun (typ : Type) -> 
                    typ.IsValueType 
                    && (match ns with | None -> true | Some ns -> typ.Namespace = ns )
                    && (match n with | None -> true | Some n -> typ.Name = n)
                    && gpa.Length = typ.GetGenericArguments().Length
                    && Array.forall2
                        (fun (casesta : SerializationTemplate array) (unioncase : UnionCaseInfo) ->
                            Array.forall2
                                (fun (st : SerializationTemplate) (field : PropertyInfo) ->
                                    SerializationTemplateToType st = field.PropertyType
                                )
                                casesta
                                (unioncase.GetFields())
                        )
                        cases
                        (FSharpType.GetUnionCases(typ))
                    )
            td
    | StRecord(sta,ti) ->
        match ti with
        | TiFullName(fn) -> Type.GetType(fn)
        | TiSearch {Name = n; Namespace = ns} -> 
            let td =
                AppDomain.CurrentDomain.GetAssemblies()
                |> Array.collect (fun (a : Assembly) -> a.GetTypes())
                |> Array.find (fun (typ : Type) -> 
                    FSharpType.IsRecord typ 
                    && (match ns with | None -> true | Some ns -> typ.Namespace = ns )
                    && (match n with | None -> true | Some n -> typ.Name = n)
                    && Array.forall2
                        (fun (st : SerializationTemplate) (pi : PropertyInfo) -> SerializationTemplateToType st = pi.PropertyType) 
                        sta
                        (FSharpType.GetRecordFields(typ))
                        )
            td
    | StUnknown -> typeof<Object>

type TypeCode() =
    static let memstream = new MemoryStream()
    static let binwrt = new BinaryWriter(memstream)
    static member Int : Byte = 2uy
    static member Float = 3uy
    static member Bool = 4uy
    static member String = 5uy
    static member NeuralAddress = 6uy
    static member List = 7uy
    static member Tuple = 8uy
    static member Array = 9uy
    static member Map = 10uy
    static member Struct = 11uy
    static member Union = 12uy
    static member Record = 13uy
    static member StringToByteArray (s : string) =
        memstream.SetLength(int64 0)
        memstream.Position <- int64 0
        binwrt.Write(s)
        memstream.ToArray()
    static member TypeIdentifierCode (typeid) = 
        match typeid with
        | TiFullName fn -> 
            Array.concat [
                [|TiCode.Fullname|];
                TypeCode.StringToByteArray fn
            ]
        | TiNamespaceName(ns,n) ->
            Array.concat [
                [|TiCode.NamespaceName|];
                (TypeCode.StringToByteArray ns);
                (TypeCode.StringToByteArray n);
            ]
        | TiName(n) ->
            Array.concat [
                [|TiCode.Name|];
                (TypeCode.StringToByteArray n);
            ]
    static member OfTemplate st =
        let (|Custom|_|) codes i =
            if Map.containsKey i codes then
                codes.[i] |> Some
            else
                None
        match st with
        | StFloat -> TypeCode.Float
        | StInt -> TypeCode.Int
        | StBool -> TypeCode.Bool
        | StNeuralAddress -> TypeCode.NeuralAddress
        | StString -> TypeCode.String
        | StList _ -> TypeCode.List
        | StTuple _ -> TypeCode.Tuple
        | StArray _ -> TypeCode.Array
        | StMap _ -> TypeCode.Map
        | StStruct _ -> TypeCode.Struct
        | StUnion _ -> TypeCode.Union
        | StRecord _ -> TypeCode.Record
        //| Custom customcodes cn -> cn
        | _ -> byte 255
    static member FullCodeOfTemplate st =
        match st with
        | StFloat -> [|TypeCode.Float|]
        | StInt -> [|TypeCode.Int|]
        | StBool -> [|TypeCode.Bool|]
        | StNeuralAddress -> [|TypeCode.NeuralAddress|]
        | StString -> [|TypeCode.String|]
        | StList sti -> Array.concat [[|TypeCode.List|]; (TypeCode.FullCodeOfTemplate sti)]
        | StTuple stl -> Array.concat [[|TypeCode.Tuple|]; [|byte stl.Length|]; Array.collect (TypeCode.FullCodeOfTemplate) stl]
        | StArray sti -> Array.concat [[|TypeCode.Array|]; (TypeCode.FullCodeOfTemplate sti)]
        | StMap(stkey,stitem) -> Array.concat [[|TypeCode.Map|]; (TypeCode.FullCodeOfTemplate stkey); (TypeCode.FullCodeOfTemplate stitem)]
        | StStruct(stl,gnl,tid) -> 
            
            Array.concat [
                [|TypeCode.Struct|]; 
                TypeCode.TypeIdentifierCode tid;
                [|byte gnl.Length|]; 
                Array.collect TypeCode.FullCodeOfTemplate gnl;
                [|byte stl.Length|]; 
                Array.collect TypeCode.FullCodeOfTemplate stl;
            ]
        | StUnion(stll,gnl,tid) -> 
            Array.concat [
                [|TypeCode.Union|]; 
                TypeCode.TypeIdentifierCode tid;
                [|byte gnl.Length|]; 
                Array.collect TypeCode.FullCodeOfTemplate gnl;
                [|byte stll.Length|]; 
                Array.collect 
                    (fun (stl : _ []) -> Array.append [|byte stl.Length|] (Array.collect TypeCode.FullCodeOfTemplate stl)) 
                    stll
            ]
        | StRecord(stl,tid) -> 
            Array.concat [
                [|TypeCode.Record|]; 
                TypeCode.TypeIdentifierCode tid; 
                [|byte stl.Length|]; 
                Array.collect (TypeCode.FullCodeOfTemplate) stl
            ]
        | _ -> [|byte 255|]
    
    static member CodeOf customcodes i =
        let (|Custom|_|) codes i =
            if Map.containsKey i codes then
                codes.[i] |> Some
            else
                None
        match i with
        | v when v = TypeCode.Float -> "Float"
        | v when v = TypeCode.Int -> "Int"
        | v when v = TypeCode.Bool -> "Bool"
        | v when v = TypeCode.NeuralAddress -> "NeuralAddress"
        | v when v = TypeCode.String -> "String"
        | v when v = TypeCode.List -> "List"
        | v when v = TypeCode.Tuple -> "Tuple"
        | v when v = TypeCode.Array -> "Array"
        | v when v = TypeCode.Map -> "Map"
        | v when v = TypeCode.Struct -> "Struct"
        | v when v = TypeCode.Union -> "Union"
        | v when v = TypeCode.Record -> "Record"
        | Custom customcodes cn -> cn
        | _ -> "Unknown Type"

type tryload<'r> =
| Result of 'r
| Eos
| TypeMismatch


let LiftOptionTuple2 (a: 'a option, b: 'b option) =
    if a.IsSome && b.IsSome then
        Some (a.Value,b.Value)
    else
        None
let LiftOptionTuple3 (a: 'a option, b: 'b option, c : 'c option) =
    if a.IsSome && b.IsSome && c.IsSome then
        Some (a.Value,b.Value,c.Value)
    else
        None
let LiftOptionTuple4 (a: 'a option, b: 'b option, c : 'c option, d : 'd option) =
    if a.IsSome && b.IsSome && c.IsSome && d.IsSome then
        Some (a.Value,b.Value,c.Value,d.Value)
    else
        None

let tup2 a b = (a,b)
let pipetup2 a b = (b,a)

let rec CreateSerializationTemplateFromType (constructors : Map<TypeIdentifier, string array>) (typ : Type) =
    let CreateSerializationTemplateFromType = CreateSerializationTemplateFromType constructors
    match typ with
    | typ when typ = typeof<int> -> StInt
    | typ when typ = typeof<float> -> StFloat
    | typ when typ = typeof<bool> -> StBool
    | typ when typ = typeof<string> -> StString
    | typ when FSharpType.IsTuple typ -> 
        typ
        |> FSharpType.GetTupleElements
        |> Array.map CreateSerializationTemplateFromType
        |> StTuple
    | typ when typ.Name = typeof<list<int>>.Name ->
        typ.GetGenericArguments().[0]
        |> CreateSerializationTemplateFromType
        |> StList
    | typ when typ.IsArray ->
        typ.GetElementType()
        |> CreateSerializationTemplateFromType
        |> StArray
    | typ when typ.Name = typeof<Map<int,int>>.Name ->
        (
        typ.GetGenericArguments().[0]
        |> CreateSerializationTemplateFromType,
        typ.GetGenericArguments().[1]
        |> CreateSerializationTemplateFromType)
        |> StMap
    | typ when FSharpType.IsUnion typ ->
        StUnion(
            (typ, BindingFlags.Public ||| BindingFlags.NonPublic)
            |> FSharpType.GetUnionCases 
            |> Array.map 
                (fun (uc : UnionCaseInfo) ->
                    uc.GetFields()
                    |> Array.map 
                        (fun (pi : PropertyInfo) ->
                            pi.PropertyType
                            |> CreateSerializationTemplateFromType
                        )
                ),
            Array.map CreateSerializationTemplateFromType (typ.GetGenericArguments()),
            TiNamespaceName(typ.Namespace, typ.Name)
        )
    | typ when FSharpType.IsRecord typ ->
        typ
        |> FSharpType.GetRecordFields
        |> Array.map (fun (pi : PropertyInfo) -> pi.PropertyType |> CreateSerializationTemplateFromType)
        |> pipetup2 (TiName typ.Name)
        |> StRecord
    | typ when typ.IsValueType && Map.exists (fun (k : TypeIdentifier) (i : string array) -> TypeMatchesTypeIdentifier (if typ.IsGenericType && typ.IsConstructedGenericType then typ.GetGenericTypeDefinition() else typ) k) constructors ->
        let typid = Map.findKey (fun (k : TypeIdentifier) (i : string array) -> TypeMatchesTypeIdentifier (if typ.IsGenericType && typ.IsConstructedGenericType then typ.GetGenericTypeDefinition() else typ) k) constructors
        let propertynames = constructors.[typid]
        StStruct(
            propertynames
            |> Array.map 
                (fun pn -> 
                    let ptyp = typ.GetProperty(pn,BindingFlags.NonPublic ||| BindingFlags.Public ||| BindingFlags.Instance).PropertyType
                    ptyp |> CreateSerializationTemplateFromType),
            Array.map CreateSerializationTemplateFromType (typ.GetGenericArguments()),
            typid
        )
    | _ -> StUnknown

let IsOfTypeDef (a : Object) (b : Type) : bool =
    let atyp = 
        let typ = a.GetType()
        if typ.IsGenericType && typ.IsConstructedGenericType then 
            typ.GetGenericTypeDefinition() 
        else 
            typ
    atyp.Namespace = b.Namespace && atyp.Name = b.Name

let MapModuleType =
    AppDomain.CurrentDomain.GetAssemblies()
    |> Array.collect (fun (a : Assembly) -> a.GetTypes())
    |> Array.find (fun (typ : Type) -> FSharpType.IsModule typ && typ.Namespace = "Microsoft.FSharp.Collections" && typ.Name = "MapModule")

let ListModuleType =
    AppDomain.CurrentDomain.GetAssemblies()
    |> Array.collect (fun (a : Assembly) -> a.GetTypes())
    |> Array.find (fun (typ : Type) -> FSharpType.IsModule typ && typ.Namespace = "Microsoft.FSharp.Collections" && typ.Name = "ListModule")

let SeqModuleType =
    AppDomain.CurrentDomain.GetAssemblies()
    |> Array.collect (fun (a : Assembly) -> a.GetTypes())
    |> Array.find (fun (typ : Type) -> FSharpType.IsModule typ && typ.Namespace = "Microsoft.FSharp.Collections" && typ.Name = "SeqModule")
    


let rec SerializeObjectUsingTemplate (savetypecode : bool) (saveto : System.IO.BinaryWriter) (constructors : Map<TypeIdentifier, string array>) (template : SerializationTemplate) (obj : Object) =
    match template with
    | StInt -> 
        if obj :? int then 
            if savetypecode then 
                saveto.Write(TypeCode.Int); 
            saveto.Write(obj :?> int)
    | StFloat -> 
        if obj :? float then 
            if savetypecode then 
                saveto.Write(TypeCode.Float); 
            saveto.Write(obj :?> float)
    | StBool -> 
        if obj :? bool then 
            if savetypecode then 
                saveto.Write(TypeCode.Bool); 
            saveto.Write(obj :?> bool)
    | StString -> 
        if obj :? string then 
            if savetypecode then 
                saveto.Write(TypeCode.String); 
            saveto.Write(obj :?> string)
    | StNeuralAddress -> 
        if obj :? NeuralAddress then 
            let na = obj :?> NeuralAddress
            if savetypecode then saveto.Write(TypeCode.NeuralAddress)
            saveto.Write(na.StructureIndex)
            saveto.Write(na.GroupIndex)
            saveto.Write(na.ClusterIndex)
            saveto.Write(na.NeuronIndex)
    | StTuple sta -> 
        if FSharpType.IsTuple (obj.GetType()) then 
            let ituptype = Type.GetType("System.Runtime.CompilerServices.ITuple")
            let tuplength = sta.Length
            if savetypecode then 
                saveto.Write(TypeCode.FullCodeOfTemplate template)
            [|for i in [0..tuplength-1] do yield ituptype.GetMethod("get_Item",BindingFlags.NonPublic|||BindingFlags.Public|||BindingFlags.Instance).Invoke(obj,[|i|])|]
            |> Array.iter2 (SerializeObjectUsingTemplate false saveto constructors) sta 
    | StList st ->
        if IsOfTypeDef obj typedefof<list<int>> then
            let listlength = obj.GetType().GetProperty("Length").GetValue(obj) :?> int
            if savetypecode then 
                saveto.Write(TypeCode.FullCodeOfTemplate template)
            saveto.Write(listlength)
            for i in obj :?> System.Collections.IEnumerable do (SerializeObjectUsingTemplate false saveto constructors st i) 
    | StArray st -> 
        let typ = obj.GetType()
        if typ.Name.[typ.Name.Length - 2 .. typ.Name.Length - 1] = "[]" && typ.Namespace = typedefof<int array>.Namespace then
            let arraylength = typ.GetProperty("Length").GetValue(obj) :?> int
            if savetypecode then 
                saveto.Write(TypeCode.FullCodeOfTemplate template)
            saveto.Write(arraylength)
            for i in obj :?> System.Collections.IEnumerable do (SerializeObjectUsingTemplate false saveto constructors st i) 
    | StMap(stkey,stitem) -> 
        if IsOfTypeDef obj typedefof<Map<int,int>> then
            let maptype = obj.GetType()
            let maplength = maptype.GetProperty("Count").GetValue(obj) :?> int
            let asarray = MapModuleType.GetMethod("ToArray", BindingFlags.Static ||| BindingFlags.Public).MakeGenericMethod(maptype.GetGenericArguments()).Invoke((),[|obj|])
            if savetypecode then 
                saveto.Write(TypeCode.FullCodeOfTemplate template)
            saveto.Write(maplength)
            for i in asarray :?> System.Collections.IEnumerable do 
                SerializeObjectUsingTemplate false saveto constructors (StTuple([|stkey;stitem|])) i
    | StStruct(constructparams, genericparams, typeidentifier) ->
        let typ = obj.GetType()
        if TypeMatchesTypeIdentifier typ typeidentifier then
            if savetypecode then saveto.Write(TypeCode.FullCodeOfTemplate template)
            saveto.Write(constructparams.Length)
            let typid = Map.findKey (fun (k : TypeIdentifier) (_) -> TypeMatchesTypeIdentifier (typ) k) constructors
            let propertynames = constructors.[typid]
            for i in [0 .. constructparams.Length - 1] do
                SerializeObjectUsingTemplate false saveto constructors (constructparams.[i]) (typ.GetProperty(constructors.[typeidentifier].[i]).GetValue(obj))
    | StUnion(cases,genericparams,typeidentifier) ->
        let typ = obj.GetType()
        if TypeMatchesTypeIdentifier typ typeidentifier then
            let case, fields = FSharpValue.GetUnionFields(obj,typ)
            let sta = cases.[case.Tag]
            if savetypecode then saveto.Write(TypeCode.FullCodeOfTemplate template)
            saveto.Write(byte case.Tag)
            Array.iter2 (SerializeObjectUsingTemplate false saveto constructors) sta fields
    | StRecord(sta,typeidentifier) ->
        let typ = obj.GetType()
        if FSharpType.IsRecord typ && TypeMatchesTypeIdentifier typ typeidentifier then
            if savetypecode then saveto.Write(TypeCode.FullCodeOfTemplate template)
            let fields = FSharpType.GetRecordFields(typ)
            for i in [0..sta.Length-1] do
                SerializeObjectUsingTemplate false saveto constructors (sta.[i]) (fields.[i].GetValue(obj))
            

    | StUnknown ->
        ()
         
(*
let SerializeObject (saveto : System.IO.BinaryWriter) (constructors : Map<TypeIdentifier, string array>) (obj : Object) (refs : Map<int,Object>) =
    
    saveto.Write(TypeCode.FullCodeOfTemplate template)

    let rec serializeobject (obj : Object) =
        let typ = obj.GetType()
        match typ with
        | typ when typ = typeof<int> ->
            saveto.Write(obj :?> int)
        | typ when typ = typeof<float> ->
            saveto.Write(obj :?> float)
        | typ when typ = typeof<bool> ->
            saveto.Write(obj :?> bool)
        | typ when typ = typeof<string> ->
            saveto.Write(obj :?> string)
        | typ when typ = typeof<NeuralAddress> ->
            let na = obj :?> NeuralAddress
            saveto.Write(na.StructureIndex)
            saveto.Write(na.GroupIndex)
            saveto.Write(na.ClusterIndex)
            saveto.Write(na.NeuronIndex)
        | typ when FSharpType.IsTuple typ ->
            let ituptype = Type.GetType("System.Runtime.CompilerServices.ITuple")
            let tuplength = FSharpType.GetTupleElements(typ).Length
            [|for i in [0..tuplength-1] do yield ituptype.GetMethod("get_Item",BindingFlags.NonPublic|||BindingFlags.Public|||BindingFlags.Instance).Invoke(obj,[|i|])|]
            |> Array.iter serializeobject
        | typ when 
            let listtyp = typedefof<List<int>>
            typ.Name = listtyp.Name && typ.Namespace = listtyp.Namespace ->
                let listlength = obj.GetType().GetProperty("Length").GetValue(obj) :?> int
                saveto.Write(listlength)
                for i in obj :?> System.Collections.IEnumerable do (serializeobject i) 
        | typ when typ.IsArray ->
            if typ.Name.[typ.Name.Length - 2 .. typ.Name.Length - 1] = "[]" && typ.Namespace = typedefof<int array>.Namespace then
                let arraylength = typ.GetProperty("Length").GetValue(obj) :?> int
                saveto.Write(arraylength)
                for i in obj :?> System.Collections.IEnumerable do (serializeobject i) 
        | typ when 
            let maptyp = typedefof<Map<int,int>>
            typ.Name = maptyp.Name && typ.Namespace = maptyp.Namespace -> 
                let maptype = obj.GetType()
                let maplength = maptype.GetProperty("Count").GetValue(obj) :?> int
                let asarray = MapModuleType.GetMethod("ToArray", BindingFlags.Static ||| BindingFlags.Public).MakeGenericMethod(maptype.GetGenericArguments()).Invoke((),[|obj|])
                saveto.Write(maplength)
                for i in asarray :?> System.Collections.IEnumerable do 
                    serializeobject i
        | typ when typ.IsValueType && Map.exists (fun (k : TypeIdentifier) (i : string array) -> TypeMatchesTypeIdentifier (if typ.IsGenericType && typ.IsConstructedGenericType then typ.GetGenericTypeDefinition() else typ) k) constructors ->
            let typid = Map.findKey (fun (k : TypeIdentifier) (i : string array) -> TypeMatchesTypeIdentifier (if typ.IsGenericType && typ.IsConstructedGenericType then typ.GetGenericTypeDefinition() else typ) k) constructors
            let propertynames = constructors.[typid]
            
            saveto.Write(propertynames.Length)
            for i in [0 .. propertynames.Length - 1] do
                serializeobject (typ.GetProperty(constructors.[typid].[i]).GetValue(obj))
        | typ when FSharpType.IsUnion typ ->
            let typ = obj.GetType()
            let case, fields = FSharpValue.GetUnionFields(obj,typ)
            saveto.Write(byte case.Tag)
            Array.iter serializeobject fields
        | typ when FSharpType.IsRecord typ ->
            let fields = FSharpType.GetRecordFields(typ)
            for i in [0..fields.Length-1] do
                serializeobject (fields.[i].GetValue(obj))
        | _ ->
            ()
    serializeobject obj
*)



let rec DeserializeTemplate (readfrom : System.IO.BinaryReader) : SerializationTemplate option =
    let dt = fun () -> DeserializeTemplate readfrom
    let identifier () = 
        match readfrom.ReadByte() with
        | v when v = TiCode.Fullname ->
            TiFullName(readfrom.ReadString()) |> Some
        | v when v = TiCode.NamespaceName ->
            TiNamespaceName(readfrom.ReadString(),readfrom.ReadString()) |> Some
        | v when v = TiCode.Name ->
            TiName(readfrom.ReadString()) |> Some
        | _ -> 
            None
    match readfrom.ReadByte() with
    | v when v = TypeCode.Float -> 
        StFloat |> Some
    | v when v = TypeCode.Int ->
        StInt |> Some
    | v when v = TypeCode.Bool -> 
        StBool |> Some
    | v when v = TypeCode.NeuralAddress -> 
        StNeuralAddress |> Some
    | v when v = TypeCode.String -> 
        StString |> Some
    | v when v = TypeCode.List -> 
        match dt() with
        | Some v ->
            StList(v) |> Some
        | None -> None
    | v when v = TypeCode.Tuple -> 
        let count = readfrom.ReadByte() |> int
        let sta = [|for _ in 1 .. count do yield dt()|]
        if Array.forall Option.isSome sta then
            StTuple(Array.map Option.get sta) |> Some
        else
            None
    | v when v = TypeCode.Array -> 
        match dt() with
        | Some v ->
            StArray(v) |> Some
        | None -> None
    | v when v = TypeCode.Map -> 
        match (dt(),dt()) with
        | (Some key,Some item) ->
            StMap(key,item) |> Some
        | _ -> None
    | v when v = TypeCode.Struct -> 
        let identifier = identifier ()
        let genparamcount = readfrom.ReadByte() |> int
        let genparams = [|for _ in 1 .. genparamcount do yield dt()|]
        let paramcount = readfrom.ReadByte() |> int
        let structparams = [|for _ in 1 .. paramcount do yield dt()|]
        if Array.forall Option.isSome genparams && Array.forall Option.isSome structparams && Option.isSome identifier then
            StStruct(Array.map Option.get structparams,Array.map Option.get genparams,Option.get identifier) |> Some
        else
            None
    | v when v = TypeCode.Union ->
        let identifier = identifier ()
        let genparamcount = readfrom.ReadByte() |> int
        let genparams = [|for _ in 1 .. genparamcount do yield dt()|]
        
        let casecount = readfrom.ReadByte() |> int
        let unioncases = 
            [|for _ in 1 .. casecount do 
                let fieldcount = readfrom.ReadByte() |> int
                yield [|for _ in 1 .. fieldcount do yield dt()|]
            |]
        if Array.forall Option.isSome genparams && Array.forall (Array.forall Option.isSome) unioncases && Option.isSome identifier then
            StUnion(Array.map (Array.map Option.get) unioncases,Array.map Option.get genparams,Option.get identifier) |> Some
        else
            None
    | v when v = TypeCode.Record -> 
        let identifier = identifier ()
        let fieldcount = readfrom.ReadByte() |> int
        let recordfields =
            [|for _ in 1 .. fieldcount do yield dt()|]
        if Array.forall Option.isSome recordfields && Option.isSome identifier then
            StRecord(Array.map Option.get recordfields,Option.get identifier) |> Some
        else
            None
    | _ ->
        None

type ReadResult<'value> =
| ReadSuccess of 'value
| ReadFailure of string * int64

let rec DeserializeObjectUsingTemplate (readfrom : System.IO.BinaryReader) (template : SerializationTemplate) : Object Option =
    let dt = DeserializeObjectUsingTemplate readfrom
    match template with
    | StFloat -> 
        readfrom.ReadDouble() :> Object |> Some
    | StInt->
        readfrom.ReadInt32() :> Object |> Some
    | StBool -> 
        readfrom.ReadBoolean() :> Object |> Some
    | StNeuralAddress -> 
        new NeuralAddress(
            readfrom.ReadInt32(),
            readfrom.ReadInt32(),
            readfrom.ReadInt32(),
            readfrom.ReadInt32()
            ) :> Object |> Some
    | StString -> 
        readfrom.ReadString() :> Object |> Some
    | StList st -> 
        let length = readfrom.ReadInt32()
        let items = [ for _ in 1 .. length do yield dt st]
        if List.forall Option.isSome items then
            let items =
                items
                |> List.map Option.get
            let itemtype = SerializationTemplateToType st
            let items = 
                let method =
                    SeqModuleType
                        .GetMethod("Cast", BindingFlags.Static ||| BindingFlags.Public)
                let genmethod =
                    method.MakeGenericMethod([|itemtype|])
                let result =
                    genmethod.Invoke((),[|items|])
                result
            let items = 
                SeqModuleType
                    .GetMethod("ToList", BindingFlags.Static ||| BindingFlags.Public)
                    .MakeGenericMethod([|itemtype|])
                    .Invoke((),[|items|])
            items
            |> Some
        else
            None
    | StTuple(stl) -> 
        let items = [ for st in stl do yield dt st]
        if List.forall Option.isSome items then
            let items =
                items
                |> List.map Option.get
                |> List.toArray
            FSharpValue.MakeTuple(items, (FSharpType.MakeTupleType(Array.map (fun i -> i.GetType()) items))) |> Some
        else
            None
    | StArray(st) -> 
        let length = readfrom.ReadInt32()
        let items = [| for _ in 1 .. length do yield dt st|]
        if Array.forall Option.isSome items then
            let items =
                items
                |> Array.map Option.get
            let itemtype = SerializationTemplateToType st
            let items = 
                let method =
                    SeqModuleType
                        .GetMethod("Cast", BindingFlags.Static ||| BindingFlags.Public)
                let genmethod =
                    method.MakeGenericMethod([|itemtype|])
                let result =
                    genmethod.Invoke((),[|items|])
                result
            let items = 
                SeqModuleType
                    .GetMethod("ToArray", BindingFlags.Static ||| BindingFlags.Public)
                    .MakeGenericMethod([|itemtype|])
                    .Invoke((),[|items|])
            items
            |> Some
        else
            None
    | StMap(stkey,stitem) -> 
        let length = readfrom.ReadInt32()
        let pairs = [ for _ in 1 .. length do yield (dt stkey, dt stitem)]
        if List.forall (fun (key : _ Option,item : _ Option) -> key.IsSome && item.IsSome) pairs then
            let keys, items =
                pairs
                |> List.map (fun (key : _ Option,item : _ Option) -> (key.Value,item.Value))
                |> List.unzip
            let keytype = SerializationTemplateToType stkey
            let itemtype = SerializationTemplateToType stitem
            let keys = 
                let method =
                    SeqModuleType
                        .GetMethod("Cast", BindingFlags.Static ||| BindingFlags.Public)
                let genmethod =
                    method.MakeGenericMethod([|keytype|])
                let result =
                    genmethod.Invoke((),[|keys|])
                result
            let items = 
                let method =
                    SeqModuleType
                        .GetMethod("Cast", BindingFlags.Static ||| BindingFlags.Public)
                let genmethod =
                    method.MakeGenericMethod([|itemtype|])
                let result =
                    genmethod.Invoke((),[|items|])
                result
            let pairs =
                let method =
                    SeqModuleType
                        .GetMethod("Zip", BindingFlags.Static ||| BindingFlags.Public)
                let genmethod =
                    method.MakeGenericMethod([|keytype; itemtype|])
                let result =
                    genmethod.Invoke((),[|keys;items|])
                result
            let map = 
                MapModuleType
                    .GetMethod("OfSeq", BindingFlags.Static ||| BindingFlags.Public)
                    .MakeGenericMethod([|keytype; itemtype|])
                    .Invoke((),[|pairs|])
                
                

            map
            |> Some
        else
            None
    | StStruct(cpa,gpa,ti) as ststruct -> 
        let typ = SerializationTemplateToType ststruct
        let cpat =
            Array.map SerializationTemplateToType cpa
        let cpav =
            Array.map dt cpa
        if Array.forall Option.isSome cpav then
            typ.GetConstructor(cpat).Invoke(Array.map Option.get cpav) |> Some
        else
            None
    | StUnion(cases,gpa,ti) as stunion -> 
        let typ = SerializationTemplateToType stunion
        let case = readfrom.ReadByte() |> int
        let fieldvalues =
            Array.map dt (cases.[case])
        if Array.forall Option.isSome fieldvalues then
            FSharpValue.MakeUnion(FSharpType.GetUnionCases(typ).[case], Array.map Option.get fieldvalues) |> Some
        else
            None
    | StRecord(sta,ti) as strecord ->
        let typ = SerializationTemplateToType strecord
        let stav =
            Array.map dt sta
        if Array.forall Option.isSome stav then
            FSharpValue.MakeRecord(typ,Array.map Option.get stav) |> Some
        else
            None
    | StUnknown -> None